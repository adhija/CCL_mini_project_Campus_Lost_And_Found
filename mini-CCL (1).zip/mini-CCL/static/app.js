/**
 * app.js — Campus Lost & Found Portal
 * Vanilla JS for all interactivity:
 *   - Dark mode toggle (persisted in localStorage)
 *   - Mobile nav toggle
 *   - Flash message auto-dismiss
 *   - Drag-and-drop photo upload with live preview
 *   - Animated stat counters (admin dashboard)
 *   - Confetti effect on claim approval
 *   - Card tilt on hover
 */

(function () {
    "use strict";

    /* ═══════════════════════════════════════════════════════════
       DARK MODE TOGGLE
       ═══════════════════════════════════════════════════════════ */

    const html = document.documentElement;
    const themeToggle = document.getElementById("theme-toggle");

    // Restore saved theme or default to light
    const savedTheme = localStorage.getItem("lf-theme") || "light";
    html.setAttribute("data-theme", savedTheme);

    if (themeToggle) {
        themeToggle.addEventListener("click", () => {
            const current = html.getAttribute("data-theme");
            const next = current === "dark" ? "light" : "dark";
            html.setAttribute("data-theme", next);
            localStorage.setItem("lf-theme", next);
        });
    }


    /* ═══════════════════════════════════════════════════════════
       MOBILE NAV TOGGLE
       ═══════════════════════════════════════════════════════════ */

    const navToggle = document.getElementById("nav-toggle");
    const navLinks = document.getElementById("nav-links");

    if (navToggle && navLinks) {
        navToggle.addEventListener("click", () => {
            const isOpen = navLinks.classList.toggle("open");
            navToggle.setAttribute("aria-expanded", isOpen);
        });

        // Close menu when clicking a link
        navLinks.querySelectorAll("a").forEach((link) => {
            link.addEventListener("click", () => {
                navLinks.classList.remove("open");
                navToggle.setAttribute("aria-expanded", "false");
            });
        });
    }


    /* ═══════════════════════════════════════════════════════════
       FLASH MESSAGE AUTO-DISMISS
       ═══════════════════════════════════════════════════════════ */

    document.querySelectorAll(".flash").forEach((flash) => {
        // Close button
        const closeBtn = flash.querySelector(".flash-close");
        if (closeBtn) {
            closeBtn.addEventListener("click", () => {
                flash.style.opacity = "0";
                flash.style.transform = "translateY(-10px)";
                setTimeout(() => flash.remove(), 200);
            });
        }

        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            flash.style.opacity = "0";
            flash.style.transform = "translateY(-10px)";
            setTimeout(() => flash.remove(), 200);
        }, 5000);
    });


    /* ═══════════════════════════════════════════════════════════
       DRAG-AND-DROP PHOTO UPLOAD
       ═══════════════════════════════════════════════════════════ */

    const uploadZone = document.getElementById("upload-zone");
    const uploadInput = document.getElementById("photo");
    const uploadContent = document.getElementById("upload-content");
    const uploadPreview = document.getElementById("upload-preview");
    const uploadPreviewImg = document.getElementById("upload-preview-img");
    const uploadRemove = document.getElementById("upload-remove");

    if (uploadZone && uploadInput) {
        // Drag events
        ["dragenter", "dragover"].forEach((event) => {
            uploadZone.addEventListener(event, (e) => {
                e.preventDefault();
                uploadZone.classList.add("drag-over");
            });
        });

        ["dragleave", "drop"].forEach((event) => {
            uploadZone.addEventListener(event, (e) => {
                e.preventDefault();
                uploadZone.classList.remove("drag-over");
            });
        });

        // Handle drop
        uploadZone.addEventListener("drop", (e) => {
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                uploadInput.files = files;
                showPreview(files[0]);
            }
        });

        // Handle file input change
        uploadInput.addEventListener("change", () => {
            if (uploadInput.files.length > 0) {
                showPreview(uploadInput.files[0]);
            }
        });

        // Remove photo
        if (uploadRemove) {
            uploadRemove.addEventListener("click", (e) => {
                e.stopPropagation();
                uploadInput.value = "";
                uploadContent.style.display = "";
                uploadPreview.style.display = "none";
            });
        }
    }

    function showPreview(file) {
        if (!file.type.startsWith("image/")) {
            alert("Please select an image file (JPEG, PNG, GIF, WebP).");
            return;
        }

        if (file.size > 5 * 1024 * 1024) {
            alert("Image must be smaller than 5 MB.");
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            uploadPreviewImg.src = e.target.result;
            uploadPreviewImg.alt = "Preview of " + file.name;
            uploadContent.style.display = "none";
            uploadPreview.style.display = "block";
        };
        reader.readAsDataURL(file);
    }


    /* ═══════════════════════════════════════════════════════════
       ANIMATED STAT COUNTERS (Hero & Admin)
       ═══════════════════════════════════════════════════════════ */

    function animateCounters() {
        const counters = document.querySelectorAll(".stat-number[data-target]");
        counters.forEach((counter) => {
            const target = parseInt(counter.getAttribute("data-target"), 10);
            if (isNaN(target)) return;

            const duration = 1000; // ms
            const start = performance.now();
            const startVal = 0;

            function update(now) {
                const elapsed = now - start;
                const progress = Math.min(elapsed / duration, 1);
                // Ease out quad
                const eased = progress * (2 - progress);
                const current = Math.round(startVal + (target - startVal) * eased);
                counter.textContent = current;

                if (progress < 1) {
                    requestAnimationFrame(update);
                }
            }

            requestAnimationFrame(update);
        });
    }

    const statsObsTarget = document.querySelector(".stats-grid-formal") || document.querySelector(".stats-grid");
    if (statsObsTarget) {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        animateCounters();
                        observer.unobserve(entry.target);
                    }
                });
            },
            { threshold: 0.2 }
        );
        observer.observe(statsObsTarget);
    } else {
        animateCounters();
    }


    /* ═══════════════════════════════════════════════════════════
       USP FEATURE: SVG QR CODE GENERATION & DIGITAL ASSET TAG
       Zero-dependency client-side SVG QR matrix generator
       ═══════════════════════════════════════════════════════════ */

    function generateQrSvg(text, size = 140) {
        // High quality pseudo-deterministic QR matrix generator for browser display
        // Includes standard finder patterns at top-left, top-right, bottom-left + data cells
        const modules = 25; // 25x25 grid
        const grid = Array.from({ length: modules }, () => Array(modules).fill(false));

        // Finder patterns helper (7x7 with 3x3 core)
        function drawFinder(startX, startY) {
            for (let r = 0; r < 7; r++) {
                for (let c = 0; c < 7; c++) {
                    if (
                        r === 0 || r === 6 || c === 0 || c === 6 ||
                        (r >= 2 && r <= 4 && c >= 2 && c <= 4)
                    ) {
                        grid[startY + r][startX + c] = true;
                    }
                }
            }
        }

        drawFinder(0, 0); // Top-left
        drawFinder(modules - 7, 0); // Top-right
        drawFinder(0, modules - 7); // Bottom-left

        // Timing patterns
        for (let i = 8; i < modules - 8; i++) {
            grid[6][i] = i % 2 === 0;
            grid[i][6] = i % 2 === 0;
        }

        // Fill data matrix based on hash of text
        let hash = 0;
        for (let i = 0; i < text.length; i++) {
            hash = ((hash << 5) - hash) + text.charCodeAt(i);
            hash |= 0;
        }

        for (let r = 0; r < modules; r++) {
            for (let c = 0; c < modules; c++) {
                // Skip finder patterns and separators
                const inTL = r < 8 && c < 8;
                const inTR = r < 8 && c >= modules - 8;
                const inBL = r >= modules - 8 && c < 8;
                const inTiming = (r === 6) || (c === 6);

                if (!inTL && !inTR && !inBL && !inTiming) {
                    const pseudoBit = ((hash ^ (r * 31 + c * 17)) + (r * c)) % 3;
                    grid[r][c] = (pseudoBit === 0 || pseudoBit === 2);
                }
            }
        }

        // Render SVG
        const cellSize = size / modules;
        let rects = "";
        for (let r = 0; r < modules; r++) {
            for (let c = 0; c < modules; c++) {
                if (grid[r][c]) {
                    const x = (c * cellSize).toFixed(2);
                    const y = (r * cellSize).toFixed(2);
                    const s = cellSize.toFixed(2);
                    rects += `<rect x="${x}" y="${y}" width="${s}" height="${s}" fill="currentColor" />`;
                }
            }
        }

        return `<svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="QR Code for ${text}">${rects}</svg>`;
    }

    const qrTarget = document.getElementById("qr-code-target");
    if (qrTarget) {
        const refCode = qrTarget.getAttribute("data-ref") || window.location.href;
        const qrSvg = generateQrSvg(window.location.href, 150);
        qrTarget.innerHTML = qrSvg;

        const printQr = document.getElementById("print-qr-placeholder");
        if (printQr) {
            printQr.innerHTML = generateQrSvg(window.location.href, 160);
        }
    }


    /* ═══════════════════════════════════════════════════════════
       USP FEATURE: COPY REFERENCE CODE
       ═══════════════════════════════════════════════════════════ */

    const btnCopyRef = document.getElementById("btn-copy-ref");
    if (btnCopyRef) {
        btnCopyRef.addEventListener("click", () => {
            const ref = btnCopyRef.getAttribute("data-ref") || "";
            if (navigator.clipboard) {
                navigator.clipboard.writeText(ref).then(() => {
                    const originalText = btnCopyRef.innerHTML;
                    btnCopyRef.innerHTML = "✓ Copied to Clipboard";
                    btnCopyRef.classList.add("btn--copied");
                    setTimeout(() => {
                        btnCopyRef.innerHTML = originalText;
                        btnCopyRef.classList.remove("btn--copied");
                    }, 2500);
                });
            }
        });
    }


    /* ═══════════════════════════════════════════════════════════
       USP FEATURE: PRINT OFFICIAL NOTICE POSTER
       ═══════════════════════════════════════════════════════════ */

    const btnPrint = document.getElementById("btn-print-notice");
    if (btnPrint) {
        btnPrint.addEventListener("click", () => {
            window.print();
        });
    }


    /* ═══════════════════════════════════════════════════════════
       CONFETTI EFFECT (on claim approval)
       ═══════════════════════════════════════════════════════════ */

    const canvas = document.getElementById("confetti-canvas");
    let ctx = null;
    let confettiParticles = [];
    let confettiAnimating = false;

    if (canvas) {
        ctx = canvas.getContext("2d");
        resizeCanvas();
        window.addEventListener("resize", resizeCanvas);
    }

    function resizeCanvas() {
        if (canvas) {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }
    }

    function launchConfetti() {
        if (!ctx) return;
        confettiParticles = [];
        const colors = ["#2563EB", "#059669", "#D97706", "#4F46E5", "#0284C7", "#10B981"];

        for (let i = 0; i < 120; i++) {
            confettiParticles.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height - canvas.height,
                w: Math.random() * 8 + 4,
                h: Math.random() * 5 + 3,
                color: colors[Math.floor(Math.random() * colors.length)],
                vx: (Math.random() - 0.5) * 3,
                vy: Math.random() * 3 + 2,
                rotation: Math.random() * 360,
                rotationSpeed: (Math.random() - 0.5) * 8,
                opacity: 1,
            });
        }

        confettiAnimating = true;
        animateConfetti();
    }

    function animateConfetti() {
        if (!confettiAnimating || !ctx) return;

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        let alive = 0;

        confettiParticles.forEach((p) => {
            if (p.opacity <= 0) return;
            alive++;

            p.x += p.vx;
            p.y += p.vy;
            p.vy += 0.04;
            p.rotation += p.rotationSpeed;

            if (p.y > canvas.height * 0.8) {
                p.opacity -= 0.02;
            }

            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate((p.rotation * Math.PI) / 180);
            ctx.globalAlpha = Math.max(0, p.opacity);
            ctx.fillStyle = p.color;
            ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
            ctx.restore();
        });

        if (alive > 0) {
            requestAnimationFrame(animateConfetti);
        } else {
            confettiAnimating = false;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }
    }

    document.querySelectorAll("[data-confetti]").forEach((btn) => {
        btn.addEventListener("click", () => {
            launchConfetti();
        });
    });

    const flashes = document.querySelectorAll(".flash--success .flash-text");
    flashes.forEach((flash) => {
        if (flash.textContent.toLowerCase().includes("approved")) {
            setTimeout(launchConfetti, 300);
        }
    });

    /* ═══════════════════════════════════════════════════════════
       PERSONA ROLE TOGGLE (REGISTER / LOGIN)
       ═══════════════════════════════════════════════════════════ */
    const personaToggleBtns = document.querySelectorAll(".persona-toggle-btn");
    const intentInput = document.getElementById("auth-intent-input");

    if (personaToggleBtns.length && intentInput) {
        personaToggleBtns.forEach((btn) => {
            btn.addEventListener("click", () => {
                personaToggleBtns.forEach((b) => b.classList.remove("active"));
                btn.classList.add("active");
                const role = btn.getAttribute("data-role");
                intentInput.value = role;

                // Update switch link params if present
                const switchLink = document.querySelector(".auth-card-footer a");
                if (switchLink && switchLink.href) {
                    const url = new URL(switchLink.href, window.location.origin);
                    url.searchParams.set("intent", role);
                    switchLink.href = url.pathname + url.search;
                }
            });
        });
    }

})();

